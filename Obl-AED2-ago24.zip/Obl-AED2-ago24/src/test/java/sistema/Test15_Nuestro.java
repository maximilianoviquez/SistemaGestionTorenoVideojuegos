package sistema;

import interfaz.Categoria;
import interfaz.Retorno;
import interfaz.Sistema;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Test15_Nuestro {
    Retorno retorno;


    @Test
    void noDeberiaInicializarSistemaConMaxSucursalesMenorOIgualA3() {
        Sistema sistema = new ImplementacionSistema();

        retorno = sistema.inicializarSistema(3);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());

        retorno = sistema.inicializarSistema(2);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());

        retorno = sistema.inicializarSistema(-1);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());

        retorno = sistema.inicializarSistema(0);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
    }

    @Test
    void deberiaInicializarSistema() {
        Sistema sistema = new ImplementacionSistema();

        retorno = sistema.inicializarSistema(4);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());

        retorno = sistema.inicializarSistema(10);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
    }

    @Test
    void registrarJugador() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(5);

        System.out.println("************************************");
        System.out.println("Registrar Jugador");
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarJugador("Pedro", "Pedro", "Diaz", Categoria.ESTANDARD);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());

        System.out.println("************************************");

    }

    @Test
    void noDeberiaRegistrarJugadorConParametrosInvalidos() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        // Alias vacío
        retorno = sistema.registrarJugador("", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Alias null
        retorno = sistema.registrarJugador(null, "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());

        // Nombre vacío
        retorno = sistema.registrarJugador("CR7", "", "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        // Nombre null
        retorno = sistema.registrarJugador("CR7", null, "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        // Apellido vacío
        retorno = sistema.registrarJugador("CR7", "Cristiano", "", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Apellido null
        retorno = sistema.registrarJugador("CR7", "Cristiano", null, Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        //Categoria Null
        retorno = sistema.registrarJugador("alias4", "Luisa", "Méndez", null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Todos Null
        retorno = sistema.registrarJugador(null, null, null, null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Todos vacio
        retorno = sistema.registrarJugador("", "", "", null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        // Alias duplicado
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        retorno = sistema.registrarJugador("CR7", "Juan", "Ronaldo", Categoria.PRINCIPIANTE);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());

    }

    @Test
    void buscarJugador(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        System.out.println("************************************");
        System.out.println("Buscar Jugador");

        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Nazarino", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        retorno = sistema.registrarJugador("Antonio", "Antonio", "Diaz", Categoria.ESTANDARD);
        retorno = sistema.registrarJugador("Luis", "Luis", "Suarez", Categoria.PROFESIONAL);

        retorno = sistema.buscarJugador("Luis");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println("Jugador buscado: "+ retorno.getValorString());
        System.out.println("Cantidad de elementos recorridos son:" + retorno.getValorInteger());

        retorno = sistema.buscarJugador("");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());

        retorno = sistema.buscarJugador("Federico");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("************************************");
    }

    @Test
    void listarJugadoresPorAliasAscendente(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        //Agregar jugadores
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Nazarino", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        retorno = sistema.registrarJugador("Antonio", "Antonio", "Diaz", Categoria.ESTANDARD);
        retorno = sistema.registrarJugador("Luis", "Luis", "Suarez", Categoria.PROFESIONAL);

        //Listar jugadores
        retorno = sistema.listarJugadoresAscendente();
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
    }
    @Test
    void listarJugadoresPorCategoria(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        //Agregar jugadores
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Nazarino", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        retorno = sistema.registrarJugador("Antonio", "Antonio", "Diaz", Categoria.ESTANDARD);
        retorno = sistema.registrarJugador("Luis", "Luis", "Suarez", Categoria.PROFESIONAL);

        //Listar jugadores
        System.out.println("Listado de jugadores por Categoria Profesional");
        System.out.println("************************************");
        retorno = sistema.listarJugadoresPorCategoria(Categoria.PROFESIONAL);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("****Fin Listado de jugadores por Categoria Profesional****");

        System.out.println("Listado de jugadores por Categoria Principiante");
        System.out.println("************************************");
        retorno = sistema.listarJugadoresPorCategoria(Categoria.PRINCIPIANTE);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("****Fin Listado de jugadores por Categoria Principiante****");

        System.out.println("Listado de jugadores por Categoria ESTANDARD");
        System.out.println("************************************");
        retorno = sistema.listarJugadoresPorCategoria(Categoria.ESTANDARD);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("****Fin Listado de jugadores por Categoria ESTANDARD****");
    }

    @Test
    void registrarEquipo(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);
        System.out.println("**************************************");
        System.out.println("Registro de Equipo");

        retorno = sistema.registrarEquipo("Boca","Emilio_Rodriguez");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());

        retorno = sistema.registrarEquipo("Peñarol","Ruglio");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Existe cuadro
        retorno = sistema.registrarEquipo("Peñarol","Ruglio");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("**************************************");
    }

    @Test
    void noDeberiaRegistrarEquipoConParametrosInvalidos() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        // Nombre de equipo vacío
        retorno = sistema.registrarEquipo("", "Emilio_Rodriguez");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Nombre de equipo null
        retorno = sistema.registrarEquipo(null, "Emilio_Rodriguez");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Manager vacío
        retorno = sistema.registrarEquipo("Boca", "");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Manager null
        retorno = sistema.registrarEquipo("Boca", null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Ambos null
        retorno = sistema.registrarEquipo(null, null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        // Ambos vacíos
        retorno = sistema.registrarEquipo("", "");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());

        retorno = sistema.registrarEquipo("Boca", "Emilio_Rodriguez");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        // Nombre de equipo duplicado
        retorno = sistema.registrarEquipo("Boca", "Ruglio");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
    }

    @Test
    void agregarJugadorAEquipo(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(10);

        retorno = sistema.registrarEquipo("Boca","Emilio Rodriguez");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());

        //Agregar jugadores
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Nazarino", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        retorno = sistema.registrarJugador("Antonio", "Antonio", "Diaz", Categoria.ESTANDARD);
        retorno = sistema.registrarJugador("Luis", "Luis", "Suarez", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Leo", "Leonel", "Messi", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Maxi", "Maximiliano", "Silvera", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Pedro", "Pedro", "Milans", Categoria.PROFESIONAL);

        //Agregar 5 jugadores al equipo que es el maximo posible
        retorno = sistema.agregarJugadorAEquipo("Boca","CR7");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.agregarJugadorAEquipo("Boca","R9");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.agregarJugadorAEquipo("Boca","Luis");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.agregarJugadorAEquipo("Boca","Leo");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.agregarJugadorAEquipo("Boca","Maxi");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());

        //Equipo vacio
        retorno = sistema.agregarJugadorAEquipo("","CR7");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Ambos campos null
        retorno = sistema.agregarJugadorAEquipo(null,null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Equipo null
        retorno = sistema.agregarJugadorAEquipo(null,"CR7");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Alias vacio
        retorno = sistema.agregarJugadorAEquipo("Boca","");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Alias null
        retorno = sistema.agregarJugadorAEquipo("Boca",null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //No existe equipo con ese nombre
        retorno = sistema.agregarJugadorAEquipo("River","CR7");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //No existe jugador con ese alias
        retorno = sistema.agregarJugadorAEquipo("Boca","CR25");
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());

        //El equipo ya tiene 5 jugadores
        retorno = sistema.agregarJugadorAEquipo("Boca","Pedro");
        assertEquals(Retorno.Resultado.ERROR_4, retorno.getResultado());
        System.out.println(retorno.getValorString());

        //Si el jugador ya pertenece a otro equipo da err 6
        retorno = sistema.registrarEquipo("Peñarol","La Fiera");
        retorno = sistema.agregarJugadorAEquipo("Peñarol","CR7");
        assertEquals(Retorno.Resultado.ERROR_6, retorno.getResultado());
        System.out.println(retorno.getValorString());

    }


    @Test
    void noDeberiaAgregarJugadorNoProfesionalAEquipo() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        retorno = sistema.registrarEquipo("Boca", "Emilio_Rodriguez");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());

        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());

        // Intentar agregar jugador no profesional
        retorno = sistema.agregarJugadorAEquipo("Boca", "Juan");
        assertEquals(Retorno.Resultado.ERROR_5, retorno.getResultado());
        System.out.println(retorno.getValorString());
    }

    @Test
    void noDeberiaAgregarJugadorAEquipoSiYaPerteneceAUno() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        retorno = sistema.registrarEquipo("Boca", "Emilio_Rodriguez");
        retorno = sistema.registrarEquipo("Nacional", "Ignacio");
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);

        retorno = sistema.agregarJugadorAEquipo("Boca", "CR7");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());

        // Intentar agregar el mismo jugador a otro equipo
        retorno = sistema.agregarJugadorAEquipo("Nacional", "CR7");
        assertEquals(Retorno.Resultado.ERROR_6, retorno.getResultado());
    }

    @Test
    void listarJugadoresDeEquipo(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);
        //Agregar jugadores
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Nazarino", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        retorno = sistema.registrarJugador("Antonio", "Antonio", "Diaz", Categoria.ESTANDARD);
        retorno = sistema.registrarJugador("Luis", "Luis", "Suarez", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Leo", "Leonel", "Messi", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Maxi", "Maximiliano", "Silvera", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Pedro", "Pedro", "Milans", Categoria.PROFESIONAL);
        //Registar equipo
        retorno = sistema.registrarEquipo("Boca","Emilio Rodriguez");
        //Agregar 5 jugadores al equipo que es el maximo posible
        retorno = sistema.agregarJugadorAEquipo("Boca","CR7");
        retorno = sistema.agregarJugadorAEquipo("Boca","R9");
        retorno = sistema.agregarJugadorAEquipo("Boca","Luis");
        retorno = sistema.agregarJugadorAEquipo("Boca","Leo");
        retorno = sistema.agregarJugadorAEquipo("Boca","Maxi");

        //Listar jugadores
        System.out.println("Listado de jugadores De Equipo Boca");
        System.out.println("************************************");
        retorno = sistema.listarJugadoresDeEquipo("Boca");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());

    }
    @Test
    void listarEquiposDescendentemente(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);
        System.out.println("**************************************");
        System.out.println("Listar Equipo Descendente");

        //Agregar jugadores
        retorno = sistema.registrarJugador("CR7", "Cristiano", "Ronaldo", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("R9", "Ronaldo", "Nazarino", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Juan", "Juan", "Perez", Categoria.PRINCIPIANTE);
        retorno = sistema.registrarJugador("Antonio", "Antonio", "Diaz", Categoria.ESTANDARD);
        retorno = sistema.registrarJugador("Luis", "Luis", "Suarez", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Leo", "Leonel", "Messi", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Maxi", "Maximiliano", "Silvera", Categoria.PROFESIONAL);
        retorno = sistema.registrarJugador("Pedro", "Pedro", "Milans", Categoria.PROFESIONAL);
        //Registar equipo
        retorno = sistema.registrarEquipo("Boca","Emilio Rodriguez");
        retorno = sistema.registrarEquipo("Peñarol","Ruglio");
        retorno = sistema.registrarEquipo("Nacional","Perez");
        //Agregar 5 jugadores al equipo que es el maximo posible
        retorno = sistema.agregarJugadorAEquipo("Boca","CR7");
        retorno = sistema.agregarJugadorAEquipo("Boca","R9");
        retorno = sistema.agregarJugadorAEquipo("Boca","Luis");
        retorno = sistema.agregarJugadorAEquipo("Boca","Leo");
        retorno = sistema.agregarJugadorAEquipo("Boca","Maxi");

        retorno = sistema.agregarJugadorAEquipo("Peñarol","Pedro");

        retorno = sistema.listarEquiposDescendente();
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());

        System.out.println("Fin Listar Equipo Descendente");
        System.out.println("**************************************");
    }

    @Test
    void registrarSucursal(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        System.out.println("************************************");
        System.out.println("Registrar Sucursales");
        //Testing OK
        retorno = sistema.registrarSucursal("SUC1","Sucursal Cordon");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal("SUC2","Sucursal Centro");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal("SUC3","Sucursal Palermo");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal("SUC4","Sucursal Pocitos");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing Error1
        retorno = sistema.registrarSucursal("SUC5","Sucursal Punta Carretas");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing Error2
        retorno = sistema.registrarSucursal("","");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal(null,"");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal(null,null);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal("",null);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal(null,"Sucursal 2");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal("","Sucursal 2");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarSucursal("Suc 9","");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error3
        retorno = sistema.registrarSucursal("SUC1","Suc 3");
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());

        System.out.println("************************************");

    }

    @Test
    void registrarConexion(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(8);

        System.out.println("************************************");
        System.out.println("Registrar Conexión en sucursales");

        retorno = sistema.registrarSucursal("SUC1","Sucursal Cordon");
        retorno = sistema.registrarSucursal("SUC2","Sucursal Centro");
        retorno = sistema.registrarSucursal("SUC3","Sucursal Palermo");
        retorno = sistema.registrarSucursal("SUC4","Sucursal Pocitos");
        retorno = sistema.registrarSucursal("SUC5","Sucursal Punta Carretas");
        retorno = sistema.registrarSucursal("SUC6","Sucursal Carrasco");

        //Testing OK
        retorno = sistema.registrarConexion("SUC1","SUC2",3);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC1","SUC3",3);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC2","SUC3",3);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC2","SUC6",3);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC1","SUC6",3);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing Error4
        retorno = sistema.registrarConexion("SUC2","SUC1",3);
        assertEquals(Retorno.Resultado.ERROR_4, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC1","SUC2",3);
        assertEquals(Retorno.Resultado.ERROR_4, retorno.getResultado());
        System.out.println(retorno.getValorString());

        //Testing Error1
        retorno = sistema.registrarConexion("SUC1","SUC3",-10);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing Error2
        retorno = sistema.registrarConexion("","SUC2",3);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion(null,"SUC2",3);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC1","",3);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC1",null,3);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion(null,null,3);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("","",3);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing Error3
        retorno = sistema.registrarConexion("SUC1","SUC7",3);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC10","SUC1",3);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.registrarConexion("SUC10","SUC7",3);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());

        System.out.println("************************************");
    }

    @Test
    void noDeberiaRegistrarConexionConLatenciaInvalida() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        retorno = sistema.registrarSucursal("SUC1", "Sucursal Cordon");
        retorno = sistema.registrarSucursal("SUC2", "Sucursal Centro");

        // Intentar registrar una conexión con latencia negativa
        retorno = sistema.registrarConexion("SUC1", "SUC2", -5);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());

        // Conexión entre sucursales inexistentes
        retorno = sistema.registrarConexion("SUC1", "SUCX", 5);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
    }


    @Test
    void actualizarConexion(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(6);

        System.out.println("************************************");
        System.out.println("Actualizar Conexión");
        //Registrar Sucursales
        retorno = sistema.registrarSucursal("SUC1","Sucursal Cordon");
        retorno = sistema.registrarSucursal("SUC2","Sucursal Centro");
        retorno = sistema.registrarSucursal("SUC3","Sucursal Palermo");
        retorno = sistema.registrarSucursal("SUC4","Sucursal Pocitos");
        retorno = sistema.registrarSucursal("SUC5","Sucursal Punta Carretas");
        //Registrar conexion
        retorno = sistema.registrarConexion("SUC1","SUC2",3);
        retorno = sistema.registrarConexion("SUC1","SUC3",3);
        retorno = sistema.registrarConexion("SUC4","SUC5",5);

        //Actualizar conexion
        retorno = sistema.actualizarConexion("SUC1", "SUC2", 10);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error1
        retorno = sistema.actualizarConexion("SUC1", "SUC2", -5);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error2
        retorno = sistema.actualizarConexion("", "SUC2", 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion(null, "SUC2", 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion("SUC2", "", 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion("", "", 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion("", null, 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion(null, null, 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion(null, "", 5);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error3
        retorno = sistema.actualizarConexion("SUC9", "SUC2", 15);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion("SUC2", "SUC9", 15);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion("SUC15", "SUC25", 15);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error4
        retorno = sistema.actualizarConexion("SUC1", "SUC4", 8);
        assertEquals(Retorno.Resultado.ERROR_4, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.actualizarConexion("SUC4", "SUC1", 8);
        assertEquals(Retorno.Resultado.ERROR_4, retorno.getResultado());
        System.out.println(retorno.getValorString());
    }

    @Test
    void noDeberiaActualizarConexionInexistente() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        retorno = sistema.registrarSucursal("SUC1", "Sucursal Cordon");
        retorno = sistema.registrarSucursal("SUC2", "Sucursal Centro");

        // Intentar actualizar conexión que no existe
        retorno = sistema.actualizarConexion("SUC1", "SUC2", 10);
        assertEquals(Retorno.Resultado.ERROR_4, retorno.getResultado());
    }

    @Test
    void analizarSucursal(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        System.out.println("************************************");
        System.out.println("Analizar Sucursal");

        retorno = sistema.registrarSucursal("SUC1","Sucursal Cordon");
        retorno = sistema.registrarSucursal("SUC2","Sucursal Centro");
        retorno = sistema.registrarSucursal("SUC3","Sucursal Palermo");

        retorno = sistema.registrarConexion("SUC1","SUC2",3);
        retorno = sistema.registrarConexion("SUC1","SUC3",3);
        //Testing OK
        retorno = sistema.analizarSucursal("SUC1");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println("SUC1 es critica: " + retorno.getValorString());
        retorno = sistema.analizarSucursal("SUC2");
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println("SUC2 es critica: " + retorno.getValorString());
        //Testing Error1
        retorno = sistema.analizarSucursal("");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.analizarSucursal(null);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error2
        retorno = sistema.analizarSucursal("S");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());

    }

    @Test
    void noDeberiaAnalizarSucursalInexistenteOCodigoInvalido() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        retorno = sistema.registrarSucursal("SUC1", "Sucursal Cordon");

        // Sucursal inexistente
        retorno = sistema.analizarSucursal("SUCX");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());

        // Código vacío
        retorno = sistema.analizarSucursal("");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
    }


    @Test
    void sucursalesParaTorneo(){
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        System.out.println("************************************");
        System.out.println("Sucursales para Torneo");

        retorno = sistema.registrarSucursal("SUC1","Sucursal Cordon");
        retorno = sistema.registrarSucursal("SUC2","Sucursal Centro");
        retorno = sistema.registrarSucursal("SUC3","Sucursal Palermo");
        retorno = sistema.registrarConexion("SUC1","SUC2",3);
        retorno = sistema.registrarConexion("SUC1","SUC3",20);
        retorno = sistema.registrarConexion("SUC2","SUC1",3);
        retorno = sistema.registrarConexion("SUC3","SUC1",20);
        retorno = sistema.registrarConexion("SUC2","SUC3",5);
        retorno = sistema.registrarConexion("SUC3","SUC2",5);

        //Testing OK
        retorno = sistema.sucursalesParaTorneo("SUC1", 25);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("Latencia maxima para SUC1: " + retorno.getValorInteger());

        retorno = sistema.sucursalesParaTorneo("SUC3", 20);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("Latencia maxima para SUC3: " + retorno.getValorInteger());

        retorno = sistema.sucursalesParaTorneo("SUC2", 10);
        assertEquals(Retorno.Resultado.OK, retorno.getResultado());
        System.out.println(retorno.getValorString());
        System.out.println("Latencia maxima para SUC2: " + retorno.getValorInteger());
        //Testing error1
        retorno = sistema.sucursalesParaTorneo("", 10);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.sucursalesParaTorneo(null, 10);
        assertEquals(Retorno.Resultado.ERROR_1, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error2
        retorno = sistema.sucursalesParaTorneo("SUC8", 10);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
        System.out.println(retorno.getValorString());
        //Testing error3
        retorno = sistema.sucursalesParaTorneo("SUC3", -5);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());
        retorno = sistema.sucursalesParaTorneo("SUC3", 0);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());
        System.out.println(retorno.getValorString());

        System.out.println("************************************");
    }

    @Test
    void noDeberiaSeleccionarSucursalesParaTorneoConParametrosInvalidos() {
        Sistema sistema = new ImplementacionSistema();
        retorno = sistema.inicializarSistema(4);

        retorno = sistema.registrarSucursal("SUC1", "Sucursal Cordon");

        // Latencia límite inválida
        retorno = sistema.sucursalesParaTorneo("SUC1", -10);
        assertEquals(Retorno.Resultado.ERROR_3, retorno.getResultado());

        // Sucursal anfitriona inexistente
        retorno = sistema.sucursalesParaTorneo("SUCX", 10);
        assertEquals(Retorno.Resultado.ERROR_2, retorno.getResultado());
    }


}
