package dominio.tad.Grafo;

import dominio.Sucursal;
import dominio.tad.ABB.ABBGen;
import dominio.tad.lista.Lista;

public class Grafo implements IGrafo {
    private int cantMaxVertices;
    private int cantActualvertices;
    private boolean esDirigido;
    private Sucursal[] vertices;
    private Arista[][] matAdy;


    public Grafo(int cantMaxVertices) {
        this.cantMaxVertices = cantMaxVertices;
        this.esDirigido = true;
        this.cantActualvertices = 0;
        this.vertices = new Sucursal[this.cantMaxVertices];
        this.matAdy = new Arista[this.cantMaxVertices][this.cantMaxVertices];

        for (int i = 0; i < this.cantMaxVertices; i++) {
            for (int j = 0; j < this.cantMaxVertices; j++) {
                this.matAdy[i][j] = new Arista();
            }
        }
    }

    public Grafo(int cantMaxVertices, boolean esDirigido) {
        this.cantMaxVertices = cantMaxVertices;
        this.esDirigido = esDirigido;
        this.cantActualvertices = 0;
        this.vertices = new Sucursal[this.cantMaxVertices];
        this.matAdy = new Arista[this.cantMaxVertices][this.cantMaxVertices];

        if (this.esDirigido) {
            for (int i = 0; i < this.cantMaxVertices; i++) {
                for (int j = 0; j < this.cantMaxVertices; j++) {
                    this.matAdy[i][j] = new Arista();
                }
            }
        } else {
            for (int i = 0; i < this.cantMaxVertices; i++) {
                for (int j = i; j < this.cantMaxVertices; j++) {
                    this.matAdy[i][j] = new Arista();
                    this.matAdy[j][i] = this.matAdy[i][j];
                }
            }
        }
    }

    public int getCantActualvertices() {
        return cantActualvertices;
    }

    private int obtenerPosVacia() {
        for (int i = 0; i < this.cantMaxVertices; i++) {
            if (this.vertices[i] == null) {
                return i;
            }
        }
        return -1;
    }

    //Antes de agregar un nuevo vértice, verifica si hay espacio con obtenerPosVacia().
    // Si hay una posición disponible, coloca el vértice ahí.
    //agrego una sucursal al grafo.
    @Override
    public void agregarVertice(Sucursal v) {
        if (this.cantActualvertices < this.cantMaxVertices) {
            int poscicionvacia = this.obtenerPosVacia();
            this.vertices[poscicionvacia] = v;
            this.cantActualvertices++;
        }
    }
//	•	Si encuentra una posición que no es null, compara esa sucursal con la buscada.
//	•	Si las sucursales coinciden (usando compareTo), devuelve el índice de la posición.
//	•	Si no encuentra la sucursal, devuelve -1.
    private int obtenerPosVertice(Sucursal v) {
        for (int i = 0; i < this.cantMaxVertices; i++) {
            if (this.vertices[i] != null) {
                Sucursal sucAux = this.vertices[i];
                if (sucAux.compareTo(v) == 0) {
                    return i;
                }
            }

        }

        return -1;
    }

    //Uso en agregarArista y actualizarConexion:
    //	En estos métodos, se necesita la posición de los vértices origen y destino
    //	para manipular las conexiones. obtenerPosVertice() facilita esta búsqueda.
    @Override
    public void agregarArista(Sucursal origen, Sucursal destino, int peso) {
        int posOrigen = this.obtenerPosVertice(origen);
        int posDestino = this.obtenerPosVertice(destino);

        if (posOrigen >= 0 && posDestino >= 0) {
            this.matAdy[posOrigen][posDestino].setExiste(true);
            this.matAdy[posOrigen][posDestino].setPeso(peso);
            if (!this.esDirigido) {
                this.matAdy[posDestino][posOrigen].setExiste(true);
                this.matAdy[posDestino][posOrigen].setPeso(peso);
            }
        }
    }

    @Override
    public Lista<Sucursal> verticesAdyacentes(Sucursal v) {
        Lista<Sucursal> adyacentes = new Lista<>();
        int posVert = this.obtenerPosVertice(v);
        for (int i = 0; i < this.cantMaxVertices; i++) {
            if (this.matAdy[posVert][i].isExiste()) {
                adyacentes.insertar(this.vertices[i]);
            }
        }
        return adyacentes;
    }

    @Override
    public boolean sonAdyacentes(Sucursal v1, Sucursal v2) {
        int posOrigen = this.obtenerPosVertice(v1);
        int posDestino = this.obtenerPosVertice(v2);

        return this.matAdy[posOrigen][posDestino].isExiste();
    }

    @Override
    public boolean existeVertice(Sucursal v) {
        return this.obtenerPosVertice(v) >= 0;
    }

    //	Localiza las posiciones de origen y destino con obtenerPosVertice.
    //	Si ambas posiciones son válidas, actualiza el peso en la matriz de adyacencia para reflejar el nuevo valor.
    //	Si el grafo no es dirigido, también actualiza la dirección inversa.
    @Override
    public void actualizarConexion(Sucursal origen, Sucursal destino, int peso) {
        int posOrigen = this.obtenerPosVertice(origen);
        int posDestino = this.obtenerPosVertice(destino);

        this.matAdy[posOrigen][posDestino].setPeso(peso);
        if (!this.esDirigido) {
            this.matAdy[posDestino][posOrigen].setPeso(peso);
        }
    }

    @Override
    public int getPesoArista(Sucursal origen, Sucursal destino) {
        int posOrigen = this.obtenerPosVertice(origen);
        int posDestino = this.obtenerPosVertice(destino);

        return this.matAdy[posOrigen][posDestino].getPeso();
    }

    //Este metodo determina si una sucursal es un punto de articulación en el grafo,
    // es decir, si su desconexión dividiría el grafo en componentes desconectados.
    @Override
    public boolean esArticulacion(Sucursal unaSucursal) {
        int posVertice = this.obtenerPosVertice(unaSucursal);//obtengo la posicion de la suc
        boolean[] visitados = new boolean[this.cantMaxVertices];
        boolean[] visitadosSubGrafo = new boolean[this.cantMaxVertices];
        Lista<Sucursal> adyacentes = this.verticesAdyacentes(unaSucursal);

        if (adyacentes.largo() <= 1) {
            return false; //No existe adyacentes entonces no es de articulacion
        }
        for (int i = 0; i < this.cantMaxVertices; i++) {
            visitados[i] = false;
            visitadosSubGrafo[i] = false;
        }
//	•	Realiza un DFS (recorrido en profundidad) desde esa
//	sucursal, marcando los nodos alcanzables en visitados.
        if (posVertice != -1) {
            dfsRec(posVertice, visitados);
        }
//como que elimino la suc
        visitadosSubGrafo[posVertice] = true;// Marca la sucursal 'unaSucursal' como "desconectada" en el segundo recorrido.
        int inicioDFS = -1;
        int ini = 0;
        boolean encontre = false;

        while(!encontre){
            if(ini < this.cantMaxVertices){
                if (ini != posVertice && this.matAdy[posVertice][ini].isExiste()) {
                    inicioDFS = ini;
                    encontre = true;
                }
                ini++;
            }
        }
        //inicio el segundo dfs
        if (inicioDFS != -1) {
            dfsRec(inicioDFS, visitadosSubGrafo);
        }
//	•	Compara ambos recorridos; si hay nodos no visitados en el
//	subgrafo tras la eliminación, la sucursal es crítica y retorna true.
        for (int i = 0; i < visitados.length; i++) {
            if(!visitadosSubGrafo[i] && visitados[i]) return true; //Es de articulación
        }
        return false; // No es  de articulación
    }

//	Realiza un DFS (recorrido en profundidad)
//	desde esa sucursal, marcando los nodos alcanzables en visitados.
    private void dfsRec(int pos, boolean[] visitados) {
        visitados[pos] = true;
        for (int i = 0; i < this.cantMaxVertices; i++) {
            if (this.matAdy[pos][i].isExiste() && !visitados[i]) {
                dfsRec(i, visitados);
            }
        }
    }

    //Estos métodos encuentran las sucursales dentro
    // de un límite de latencia desde una sucursal anfitriona usando Dijkstra.
    //	•	Llama al metodo dijsktra, que devuelve un ABB de sucursales alcanzables dentro de la latencia.
    //	•	Retorna una lista ordenada de sucursales en formato ascendente.

//Inicializa los costos de todas las sucursales en Integer.MAX_VALUE (infinito), excepto el origen, que tiene costo 0.
//Usa el algoritmo de Dijkstra para calcular el camino más corto desde la sucursal anfitriona a todas las demás.
//actualizarCostosAnteriores ajusta los costos de los nodos adyacentes.
//obtenerPosMenorCostoNoVisitado encuentra el vértice con el menor costo que aún no ha sido visitado y está dentro del límite de latencia.
//Retorna un ABB con las sucursales alcanzables dentro del límite de latencia
    private ABBGen<Sucursal> dijsktra(Sucursal sucAnfitriona, int latenciaLimite, int[] valorEntero) {
        ABBGen<Sucursal> abbSucursal = new ABBGen<Sucursal>();
        int posOrigen = this.obtenerPosVertice(sucAnfitriona);

        boolean[] visitados = new boolean[this.cantMaxVertices];
        int[] costos = new int[this.cantMaxVertices];
        int[] anteriores = new int[this.cantMaxVertices];

        for (int i = 0; i < this.cantMaxVertices; i++) {
            visitados[i] = false;
            costos[i] = Integer.MAX_VALUE;
            anteriores[i] = -1;
        }
        //Marcamos en 0 el costo en vertice inicial
        costos[posOrigen] = 0;
        int mayorCosto=0;

        int minPos = posOrigen;
        while (minPos > -1) {
            actualizarCostosAnteriores(costos, minPos, visitados, anteriores);
            minPos = this.obtenerPosMenorCostoNoVisitado(costos, visitados, latenciaLimite);
            if(minPos!=-1){
                abbSucursal.insertar(this.vertices[minPos]);
                mayorCosto = costos[minPos];
            }
        }

        valorEntero[0] = mayorCosto;

        return abbSucursal;
    }

    private void actualizarCostosAnteriores(int[] costos, int postActual, boolean[] visitados, int[] anteriores) {
        for (int i = 0; i < this.cantMaxVertices; i++) {
            int costo_ir_desde_vertice_actual = costos[postActual] + matAdy[postActual][i].getPeso();
            if (matAdy[postActual][i].isExiste() && !visitados[i] && costos[i] > costo_ir_desde_vertice_actual) {
                costos[i] = costo_ir_desde_vertice_actual;
                anteriores[i] = postActual;
            }
        }
    }

    private int obtenerPosMenorCostoNoVisitado(int[] costos, boolean[] visitados,int latenciaMaxima) {
        int minPos = -1;
        int minValue = Integer.MAX_VALUE;
        for (int i = 0; i < this.cantMaxVertices; i++) {
            if (!visitados[i] && costos[i] < minValue) {
                minValue = costos[i];
                minPos = i;
            }
        }
        if (minPos != -1) {
            if(costos[minPos]>latenciaMaxima) return -1;
            visitados[minPos] = true;
        }
        return minPos;
    }

    //Estos métodos calculan las sucursales alcanzables dentro de un límite
    // de latencia desde una sucursal anfitriona usando el algoritmo de Dijkstra.
    public String sucursalesParaTorneo(Sucursal sucAnfitriona, int latenciaLimite, int[] valorEntero) {
        ABBGen<Sucursal> resultadoDijsktra = dijsktra(sucAnfitriona, latenciaLimite, valorEntero);
        return resultadoDijsktra.listarAscendente();
    }
}
