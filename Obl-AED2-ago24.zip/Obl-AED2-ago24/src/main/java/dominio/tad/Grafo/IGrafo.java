package dominio.tad.Grafo;

import dominio.Sucursal;
import dominio.tad.lista.Lista;

public interface IGrafo {

    public void agregarVertice(Sucursal v);
    public void agregarArista(Sucursal origen,Sucursal destino,int peso);
    public Lista<Sucursal> verticesAdyacentes(Sucursal v);
    public boolean sonAdyacentes(Sucursal v1, Sucursal v2);
    public boolean existeVertice (Sucursal v);
    public void actualizarConexion(Sucursal origen,Sucursal destino,int peso);
    public int getPesoArista (Sucursal origen,Sucursal destino);
    public boolean esArticulacion(Sucursal unaSucursal);
    public String sucursalesParaTorneo(Sucursal sucAnfitriona, int latenciaLimite, int[] valorEntero);
}
