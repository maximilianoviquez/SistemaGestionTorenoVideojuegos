package dominio.tad.ABB;

public class ABBGen <T extends Comparable<T>> implements IAbb<T> {
    private NodoABBGen<T> raiz;
    private int cantidad = 0;

    public ABBGen() {
    }

    public ABBGen(T dato) {
        this.raiz = new NodoABBGen<>(dato);
    }

    @Override
    public void insertar(T dato) {
        if (this.raiz == null) {
            this.raiz = new NodoABBGen<T>(dato);
            this.cantidad++;
        } else {
            insertarRec(this.raiz, dato);
        }
    }

    private void insertarRec(NodoABBGen<T> nodo, T dato) {
        if (dato.compareTo(nodo.getDato())>0) {
            if (nodo.getDer() == null) {
                this.cantidad++;
                nodo.setDer(new NodoABBGen<>(dato));
            } else {
                insertarRec(nodo.getDer(), dato);
            }
        } else {
            if (nodo.getIzq() == null) {
                this.cantidad++;
                nodo.setIzq(new NodoABBGen<>(dato));
            } else {
                insertarRec(nodo.getIzq(), dato);
            }
        }
    }

    public int getCantidad() {
        return cantidad;
    }

    @Override
    public String listarAscendente() {
        if (this.raiz == null) {
            return "";
        }
        return listarAscendenteRec(this.raiz,"").strip();
    }

    private String listarAscendenteRec(NodoABBGen<T> nodo, String resultado) {
        if (nodo == null) {
            return resultado;
        }
        resultado = listarAscendenteRec(nodo.getIzq(), resultado);

        if (!resultado.isEmpty()) {
            resultado += "|";
        }
        resultado += nodo.getDato().toString();

        resultado = listarAscendenteRec(nodo.getDer(), resultado);

        return resultado;
    }

    @Override
    public String listarDescendente() {
        return listarDescendenteRec(this.raiz,"").strip();
    }

    private String listarDescendenteRec(NodoABBGen<T> nodo, String resultado) {
        if (nodo == null) {
            return resultado;
        }
        resultado = listarDescendenteRec(nodo.getDer(), resultado);

        if (!resultado.isEmpty()) {
            resultado += "|";
        }
        resultado += nodo.getDato().toString();

        resultado = listarDescendenteRec(nodo.getIzq(), resultado);
        return resultado;
    }

    @Override
    public boolean existe(T dato) {
        return existe(this.raiz, dato);
    }

    private boolean existe(NodoABBGen<T> nodo, T dato) {
        if (nodo != null) {
            if (nodo.getDato().compareTo(dato) == 0) {
                return true;
            } else if (dato.compareTo(nodo.getDato()) > 0) {
                return existe(nodo.getDer(), dato);
            } else {
                return existe(nodo.getIzq(), dato);
            }
        }
        return false;
    }

    @Override
    public T buscarDato (T dato, int[] cantElementos){

        return buscarDatoRec (raiz, dato, cantElementos);
    }

    private T buscarDatoRec (NodoABBGen<T> nodo, T dato, int[] cantElementos){
        if(nodo != null){
            cantElementos[0] ++;
            if (nodo.getDato().compareTo(dato) == 0) {
                return nodo.getDato();
            } else if (dato.compareTo(nodo.getDato()) > 0) {
                return buscarDatoRec(nodo.getDer(), dato, cantElementos);
            } else if (dato.compareTo(nodo.getDato()) < 0) {
                return buscarDatoRec(nodo.getIzq(), dato, cantElementos);
            }
        }
        return null;
    }

    @Override
    public T retornarDato (T dato){
        return retornarDatoRec (raiz, dato);
    }

    private T retornarDatoRec (NodoABBGen<T> nodo, T dato){
        if(nodo != null){
            if (nodo.getDato().compareTo(dato) == 0) {
                return nodo.getDato();
            } else if (dato.compareTo(nodo.getDato()) > 0) {
                return retornarDatoRec(nodo.getDer(), dato);
            } else if (dato.compareTo(nodo.getDato()) < 0){
                return retornarDatoRec(nodo.getIzq(), dato);
            }
        }
        return null;
    }

}
