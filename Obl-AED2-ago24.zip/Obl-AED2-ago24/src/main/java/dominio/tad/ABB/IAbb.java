package dominio.tad.ABB;

import dominio.tad.lista.Lista;

public interface IAbb <T extends Comparable <T>>{
    public void insertar(T dato);
    public String listarAscendente();
    public String listarDescendente ();

    public boolean existe(T dato);

    public T buscarDato (T dato, int[] cantElementos);
    public T retornarDato (T dato);


}
