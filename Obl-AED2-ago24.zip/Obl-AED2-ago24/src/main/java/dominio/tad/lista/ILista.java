package dominio.tad.lista;

public interface ILista<T> {

    public void insertar(T dato);

    public void agregarFinal(T x);

    public boolean existe(T dato);

    public T recuperar(int indice);

    public int largo();

    public String mostrarIter();

    public void insertarOrdenado(T x);
}
