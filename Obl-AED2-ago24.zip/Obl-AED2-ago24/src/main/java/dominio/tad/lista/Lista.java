package dominio.tad.lista;



public class Lista<T extends Comparable <T>>  implements ILista<T> {
    private Nodo<T> inicio;
    private int cantidad;

    public Lista(Nodo<T> inicio) {
        this.inicio = inicio;
        this.cantidad = (inicio != null) ? 1 : 0;
    }

    public Lista() {
        inicio = null;
        this.cantidad = 0;
    }

    public Nodo<T> getInicio() {
        return inicio;
    }

    public void setInicio(Nodo<T> inicio) {
        this.inicio = inicio;
    }

    public int getCantidad(){
        return this.cantidad;
    }

    @Override
    public void insertar(T dato) {
        this.inicio=new Nodo<T>(dato,this.inicio);
        this.cantidad++;
    }

    public void agregarFinal(T x) {
        Nodo<T> pActual = this.inicio;
        Nodo<T> nuevo = new Nodo<T>(x);
        if(this.inicio == null){
            this.inicio = nuevo;
        }else{
            while(pActual.getSig() != null){
                pActual = pActual.getSig();
            }
            pActual.setSig(nuevo);
        }
        this.cantidad++;
    }

    @Override
    public boolean existe(T dato) {
        Nodo<T> pActual = inicio;
        boolean estaElem = false;
        while(pActual != null && !estaElem){
            if(pActual.getDato().compareTo(dato)== 0){
                estaElem = true;
            }else{
                pActual = pActual.getSig();
            }
        }
        return estaElem;
    }


    @Override
    public T recuperar(int indice) {
        Nodo<T> actual = inicio;
        int contador = 0;
        while (contador < indice) {
            actual = actual.getSig();
            contador++;
        }
        return actual.getDato();
    }


    @Override
    public int largo() {
        return this.cantidad;
    }

    @Override
    public String mostrarIter() {
        Nodo<T> pActual = this.inicio;
        String resultado = "";
        while(pActual != null){
           resultado += pActual.getDato().toString();
           if(pActual.getSig()!= null){
               resultado+="|";
           }
            pActual = pActual.getSig();
        }
        return  resultado;
    }


    @Override
    public void insertarOrdenado(T x) {
        if(this.inicio == null || x.compareTo(this.inicio.getDato()) < 0) {
            this.insertar(x);
        }else{
            Nodo<T> actual = inicio;
            while(actual.getSig() != null && actual.getSig().getDato().compareTo(x) < 0){
                actual = actual.getSig();
            }
            Nodo<T> nuevoNodo = new Nodo<T>(x);
            nuevoNodo.setSig(actual.getSig());
            actual.setSig(nuevoNodo);
            this.cantidad++;
        }

    }


}
