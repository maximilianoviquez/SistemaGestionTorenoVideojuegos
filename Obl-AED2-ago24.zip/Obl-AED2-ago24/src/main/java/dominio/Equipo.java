package dominio;

import dominio.tad.ABB.ABBGen;


public class Equipo implements Comparable<Equipo> {
    private String nombre;
    private String manager;
    private ABBGen<Jugador> abbJugadores;

    public Equipo(String nombre, String manager) {
        this.nombre = nombre;
        this.manager = manager;
        this.abbJugadores = new ABBGen<>();
    }


    public Equipo (String nombre){
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }


    public String listarJugadoresAscendente(){
        return this.abbJugadores.listarAscendente();
    }

    @Override
    public int compareTo(Equipo o) {
        return this.nombre.compareTo(o.nombre);
    }

    public int cantidadJugadores(){
        return this.abbJugadores.getCantidad();

    }

    public boolean existeJugador(Jugador unJugador){
        return this.abbJugadores.existe(unJugador);
    }

    //Insertamos los jugadores ordenados por Alias, esto sirve para el requerimiento de listar
    //los jugadores de un equipo ordenados por Alias.
    public void agregarJugador(Jugador unJugador){

        abbJugadores.insertar(unJugador);
    }

     @Override
    public String toString() {
        return  this.nombre +";" + this.manager +";" +
                cantidadJugadores();
    }
}
