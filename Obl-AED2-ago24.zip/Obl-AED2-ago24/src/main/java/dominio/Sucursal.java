package dominio;

public class Sucursal implements Comparable<Sucursal> {
    private String codigo;
    private String nombre;

    public Sucursal(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public Sucursal(String codigo) {
        this.codigo = codigo;
        this.nombre = "";
    }

    public String getCodigo() {
        return codigo;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public int compareTo(Sucursal obj) {
        return this.codigo.compareTo(obj.codigo);
    }

    @Override
    public String toString() {
        return  this.codigo +";"+ this.nombre;
    }
}
