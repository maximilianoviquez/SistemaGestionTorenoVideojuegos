package dominio;

import java.util.Objects;

import interfaz.Categoria;

public class Jugador implements Comparable<Jugador>  {
    private String alias;
    private String nombre;
    private String apellido;
    private Categoria categoria;
    private Equipo equipo;

    public Jugador(String alias, String nombre, String apellido, Categoria categoria) {

        this.alias = alias;
        this.nombre = nombre;
        this.apellido = apellido;
        this.categoria = categoria;
        this.equipo = null; //Cuando se crea un jugador no pertenece a ningun equipo
    }

    public Jugador(String alias) {
        this.alias = alias;
        this.nombre = "";
        this.apellido = "";
        this.categoria = null;
        this.equipo = null;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public String getAlias() {
        return alias;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Jugador jugador = (Jugador) o;
        return Objects.equals(alias, jugador.alias);
    }

    @Override
    public int compareTo(Jugador obj) {
        return this.alias.compareTo(obj.getAlias());
    }

    @Override
    public String toString() {
        return this.alias +";"+
                this.nombre +";" + this.apellido +";" +
                this.categoria.name();
    }
}
