package sistema;

import dominio.Equipo;
import dominio.Jugador;
import dominio.Sucursal;
import dominio.tad.ABB.ABBGen;
import dominio.tad.Grafo.Grafo;
import interfaz.*;

public class ImplementacionSistema implements Sistema {
    private ABBGen<Jugador> jugadorABB;
    private ABBGen<Equipo> equipoABB;
    private Grafo sucursalesGrafo;
    private int cantMaximaSucursales;
    // ARBOLES BB POR CADA CATEGORIA:
    private ABBGen<Jugador> arbolCatPrincipiante;
    private ABBGen<Jugador> arbolCatEstandar;
    private ABBGen<Jugador> arbolCatProfesional;

    /* Retornos posibles:
    OK Si pudo inicializar el sistema correctamente.
    ERROR 1. Si cantidad máxima de sucursales <= 3
    NO_IMPLEMENTADA Cuando aún no se implementó. Es el tipo de retorno por defecto.*/
    @Override
    public Retorno inicializarSistema(int maxSucursales) {
        if(maxSucursales <= 3){
            return Retorno.error1("El maximo de sucursales permitidos es 3 y el ingreso fue:" + maxSucursales);

        }else{
            this.cantMaximaSucursales = maxSucursales;
            this.jugadorABB = new ABBGen<Jugador>();
            this.equipoABB = new ABBGen<Equipo>();
            this.sucursalesGrafo = new Grafo(this.cantMaximaSucursales,false); //Grafo no dirigido
            // ARBOLES BB POR CADA CATEGORIA:
            this.arbolCatPrincipiante = new ABBGen<>();
            this.arbolCatEstandar = new ABBGen<>();
            this.arbolCatProfesional = new ABBGen<>();
            return Retorno.ok(maxSucursales, "Sistema inicializado existosamente");
        }

    }

    /* Retornos posibles:
   OK Si el jugador fue registrado exitosamente.
   ERROR 1. Si alguno de los parámetros ess vacío o null.
   ERRO 2. Si ya existe un jugador registrado con ese alias.
   NO_IMPLEMENTADA Cuando aún no se implementó. Es el tipo de retorno por defecto.

   Descripción: Registra el jugador con sus datos. El alias es su identificador único.
   Restricción de eficiencia: Esta operación deberá realizarse en orden O(log n)
                              promedio siendo n la cantidad total de jugadores.*/
    @Override
    public Retorno registrarJugador(String alias, String nombre, String apellido, Categoria categoria) {
        Jugador unJugador = new Jugador(alias,nombre,apellido,categoria);
        if(alias == "" || alias == null || nombre == "" || nombre == null || apellido == "" || apellido == null || categoria == null || categoria.getTexto() == "" ){
            return Retorno.error1("Los campos no pueden ser null o vacío");
        }
        if(jugadorABB != null && jugadorABB.existe(unJugador)){
                return Retorno.error2("Existe un jugador con ese alias");
        }else{
            jugadorABB.insertar(unJugador);
            switch (categoria) {
                case PRINCIPIANTE:
                    arbolCatPrincipiante.insertar(unJugador);
                    break;
                case ESTANDARD:
                    arbolCatEstandar.insertar(unJugador);
                    break;
                case PROFESIONAL:
                    arbolCatProfesional.insertar(unJugador);
                    break;
            }
            return Retorno.ok("Se registro el jugador " + unJugador.getAlias());
        }

    }

    /*Restricción de eficiencia: Esta operación deberá realizarse en orden O(log n)
     promedio siendo n la cantidad total de jugadores.
     Retornos posibles: OK: Si el jugador se encontró y retorna en valorString los datos del jugador.
     Retorna en valorEntero la cantidad de elementos recorridos durante la búsqueda.
     Error1: Si el alias es vacio o null
     Error2: Si no existe jugador registrado con ese alias.     */
    @Override
    public Retorno buscarJugador(String alias) {
        if(alias == null){
            return Retorno.error1("Error 1 -> El alias es null");
        }
        if(alias.isEmpty()){
            return Retorno.error1("Error 1 -> El alias es vacío");
        }
        Jugador unJugador = new Jugador(alias);
        int[] cantElementos = {0}; //Retornamos la cantidad de recorridas hasta encontrar el jugador
        Jugador jugadorEncontrado = jugadorABB.buscarDato(unJugador, cantElementos);
        if(jugadorEncontrado != null){
            String valorString = jugadorEncontrado.toString();
            return Retorno.ok(cantElementos[0], valorString);
        }
        return Retorno.error2("Error 2 -> No existe jugador registrado con ese alias");
    }

    /*Descripción: Retorna en valorString los datos de todos los jugadores registrados,
     ordenados por alias en forma creciente.
     Restricción de eficiencia: Esta operación deberá realizarse en orden O(n) siendo n
     la cantidad total de jugadores.
     Retornos posibles: ok= Retornando el listado de jugadores en valorString.
     No hay errores posibles y NO_IMPLEMENTADA: Cuando aún no se implementó.     */
    @Override
    public Retorno listarJugadoresAscendente() {
        String listaJugadoresAsc = jugadorABB.listarAscendente();
        return Retorno.ok(listaJugadoresAsc);
    }


    /*Descripción: Retorna en valorString los datos de todos los jugadores registrados
     con esa categoría ordenados de forma creciente por alias.
     Restricción de eficiencia: Esta operación deberá realizarse en orden O(k), siendo k
     la cantidad de jugadores con dicha categoría.
     Resultado posible: ok= Si se pudo listar los jugadores que pertenecen a esa categoría correctamente.
     Error= No hay errores posibles y NO_IMPLEMENTADA Cuando aún no se implementó. */
    @Override
    public Retorno listarJugadoresPorCategoria(Categoria unaCategoria) {
        String jugadoresOrdenados = "";
        switch (unaCategoria) {
            case PRINCIPIANTE:
                jugadoresOrdenados = arbolCatPrincipiante.listarAscendente();
                break;
            case ESTANDARD:
                jugadoresOrdenados = arbolCatEstandar.listarAscendente();
                break;
            case PROFESIONAL:
                jugadoresOrdenados = arbolCatProfesional.listarAscendente();
                break;
            default:
                return Retorno.error1("Categoría no válida.");
        }
        return Retorno.ok(jugadoresOrdenados);
    }



     /*Descripción: Registra el equipo en el sistema indicando su nombre (identificador único) y el nombre del mánager.
    Restricción de eficiencia: Esta operación deberá realizarse en orden O(log n) promedio siendo n la cantidad total de equipos.
    Retornos posibles: OK= Si el equipo fue registrado exitosamente.
    ERROR1= Si alguno de los parámetros es vacío o null.
    Error2= Si ya existe un equipo con ese nombre.
    NO_IMPLEMENTADA= Cuando aún no se implementó.*/
    @Override
    public Retorno registrarEquipo(String nombre, String manager) {
        if(nombre == null || nombre.isEmpty() || manager == null || manager.isEmpty()){
            return Retorno.error1("Los parametros no pueden ser vacios o null");
        }
        Equipo unEquipo = new Equipo(nombre, manager);
        if(equipoABB.existe(unEquipo)){
            return Retorno.error2("Ya existe un equipo con ese nombre");
        }
        equipoABB.insertar(unEquipo);
        return Retorno.ok("Se agrego el equipo correctamente");
       
    }

    /*Descripción: Agrega el jugador al equipo indicado, un equipo puede tener un máximo de cinco integrantes. Solo se puede agregar jugadores
     que tengan la categoría “Profesional”.
    Restricción de eficiencia: Esta operación deberá realizarse en orden O(log n) + O(log m) promedio siendo n la cantidad total de equipos y
    m la cantidad total de jugadores.
    Retornos posibles: OK= Si la aerolínea fue registrada exitosamente.
    ERROR1= Si alguno de los parámetros es vacío o null.
    Error2= Si no existe un equipo con ese nombre.
    Error3= Si no existe un jugador con ese alias.
    Error4= Si el equipo ya tiene 5 integrantes.
    Error5= Si el jugador no tiene la categoría profesional.
    Error6= Si el jugador ya pertenece a otro equipo.
    NO_IMPLEMENTADA= Cuando aún no se implementó. */
    @Override
    public Retorno agregarJugadorAEquipo(String nombreEquipo, String aliasJugador) {
        if(nombreEquipo == "" || nombreEquipo == null || aliasJugador == "" || aliasJugador == null){
            return Retorno.error1("Los parametros no pueden ser vacios o null");
        }
        Equipo unEquipo = new Equipo(nombreEquipo);
        Jugador unJugador = new Jugador(aliasJugador);

        Equipo equipoBuscado = equipoABB.retornarDato(unEquipo);
        Jugador jugadorBuscado = jugadorABB.retornarDato(unJugador);

        if(equipoBuscado != null){
            if(jugadorBuscado == null){
                return Retorno.error3("No existe un jugador con ese alias");
            }
            if(equipoBuscado.cantidadJugadores() == 5){
                return Retorno.error4("El equipo ya tiene el maximo de jugadores permitidos, que es 5");
            }
            if(jugadorBuscado.getCategoria() != Categoria.PROFESIONAL){
                return Retorno.error5("El jugador debe de tener categoria Profesional");
            }

           if(jugadorBuscado.getEquipo() != null){
                return Retorno.error6("El jugador ya se encuentra en otro equipo");
           }
           equipoBuscado.agregarJugador(jugadorBuscado);
           jugadorBuscado.setEquipo(equipoBuscado);
            return Retorno.ok("Se agrego el jugador al equipo correctamente el jugador: " +  jugadorBuscado.getAlias());
        }else{
            return Retorno.error2("No existe un equipo con ese nombre");
        }
    }

    /*Descripción: Retorna en valorString los datos de todos los jugadores pertenecientes al equipo ordenados de forma creciente por alias.
    Restricción de eficiencia: Esta operación deberá realizarse en orden O(log n) promedio, siendo n la cantidad total de equipos.
    Retornos posibles: OK= Si se pudo listar los jugadores que pertenecen a dicho equipo.
    ERROR1= Si el nombre es vacío o null.
    Error2= Si no existe un equipo con ese nombre.
    NO_IMPLEMENTADA= Cuando aún no se implementó.*/
    @Override
    public Retorno listarJugadoresDeEquipo(String nombreEquipo) {
        if(nombreEquipo == null){
            return Retorno.error1("Los parametros no pueden ser vacios o null");
        }
        if(nombreEquipo.isEmpty()){
            return Retorno.error1("Los parametros no pueden ser vacios o null");
        }
        Equipo unEquipo = new Equipo(nombreEquipo);    
        Equipo equipoBuscado = equipoABB.retornarDato(unEquipo);
        if(equipoBuscado == null){
            return Retorno.error2("No existe un equipo con ese nombre");
        }

        String jugadoresAsc = equipoBuscado.listarJugadoresAscendente();
        return Retorno.ok(jugadoresAsc);
    }


    /*Descripción: Retorna en valorString los datos de todos los equipos ordenados por nombre en forma decreciente.
    Restricción de eficiencia: Esta operación deberá realizarse en orden O(n) siendo n la cantidad total de equipos.
    Retornos posibles: OK= Retornando el listado de equipos en valorString.
    ERROR= No hay errores posibles.
    NO_IMPLEMENTADA=Cuando aún no se implementó. */
    @Override
    public Retorno listarEquiposDescendente() {
        String listaEquipoDesc = equipoABB.listarDescendente();
        return Retorno.ok(listaEquipoDesc);
    }

    /*Descripción: Registra la sucursal en el sistema con el código y nombre indicado. El código es el identificador único, el código y nombre no pueden ser vacíos.
    Retornos posibles: OK= Si la sucursal fue registrada exitosamente.
    ERROR1= Si en el sistema ya hay registrados maxSucursales.
    Error2= Si código o nombre son vacíos o null.
    Error3= Si ya existe una sucursal con ese código.
    NO_IMPLEMENTADA= Cuando aún no se implementó.*/
    @Override
    public Retorno registrarSucursal(String codigo, String nombre) {
        if(codigo == null || codigo.isEmpty() || nombre == null || nombre.isEmpty()){
            return  Retorno.error2("Error2 -> El código o el nombre son vacios");
        }

        Sucursal unaSucursal = new Sucursal(codigo,nombre);
        if(sucursalesGrafo.getCantActualvertices() > 0 && sucursalesGrafo.existeVertice(unaSucursal)){
            return  Retorno.error3("Error3 -> Ya existe una sucursal con ese codigo " + codigo);
        }
        if(cantMaximaSucursales == sucursalesGrafo.getCantActualvertices()){
            return  Retorno.error1("Se llegó al máximo de sucursales");
        }
        sucursalesGrafo.agregarVertice(unaSucursal);
        return Retorno.ok("Sucursal agregada con exito " + codigo);
    }

    /*Descripción: Registra una conexión entre dos sucursales y la latencia de dicha conexión, la conexión es bidireccional.
    Retornos posibles: OK= Si la conexión fue registrada exitosamente.
    ERROR1= Si latencia es menor a 0.
    Error2= Si alguno de los parámetros String es vacío o null.
    Error3= Si no existe alguna de las sucursales con los códigos indicados.
    Error4= Si ya existe una conexión entre las dos sucursales.
    NO_IMPLEMENTADA= Cuando aún no se implementó.*/
    @Override
    public Retorno registrarConexion(String codigoSucursal1, String codigoSucursal2, int latencia) {
       if(latencia < 0){
           return Retorno.error1("Error 1 -> La latencia no puede ser menor a 0");
       }
       if(codigoSucursal1 == null || codigoSucursal1.isEmpty() || codigoSucursal2 == null ||  codigoSucursal2.isEmpty() ){
           return Retorno.error2("Error 2 -> Los codigos de sucursal no pueden vacios o nulos");
       }
       Sucursal sucursal1 = new Sucursal(codigoSucursal1);
       Sucursal sucursal2 = new Sucursal(codigoSucursal2);
       if(!sucursalesGrafo.existeVertice(sucursal1) || !sucursalesGrafo.existeVertice(sucursal2)){
           return Retorno.error3("Error 3 -> No existe alguna de las sucursales con los códigos indicados");
       }

       if(sucursalesGrafo.sonAdyacentes(sucursal1,sucursal2)){
           return Retorno.error4("Error 4 -> Ya existe una conexión entre las sucursales "+ sucursal1.getCodigo() + " y " + sucursal2.getCodigo());
       }
       sucursalesGrafo.agregarArista(sucursal1,sucursal2,latencia);
       return Retorno.ok("OK -> Se agregó la conexión entre las sucursales "+ sucursal1.getCodigo() + " y " + sucursal2.getCodigo());
    }

    /*Descripción: Actualiza la latencia de la conexión entre dos sucursales (la conexión es bidireccional).
    Retornos posibles: OK= Si la latencia de la conexión fue actualizada exitosamente.
    ERROR1= Si latencia es menor a 0.
    Error2= Si alguno de los parámetros String es vacío o null.
    Error3= Si no existe alguna de las sucursales con los códigos indicados.
    Error4= Si no existe una conexión entre las sucursales.
    NO_IMPLEMENTADA= Cuando aún no se implementó.*/
    @Override
    public Retorno actualizarConexion(String codigoSucursal1, String codigoSucursal2, int latencia) {
        if(latencia < 0){
            return Retorno.error1("Error 1 -> La latencia no puede ser menor a 0");
        }
        if(codigoSucursal1 == null || codigoSucursal1.isEmpty() || codigoSucursal2 == null ||  codigoSucursal2.isEmpty()){
            return Retorno.error2("Error 2 -> Los codigos de sucursal no pueden vacios o nulos");
        }
        Sucursal sucursal1 = new Sucursal(codigoSucursal1);
        Sucursal sucursal2 = new Sucursal(codigoSucursal2);
        if(!sucursalesGrafo.existeVertice(sucursal1) || !sucursalesGrafo.existeVertice(sucursal2)){
            return Retorno.error3("Error 3 -> No existe alguna de las sucursales con los códigos indicados");
        }
        if(!sucursalesGrafo.sonAdyacentes(sucursal1,sucursal2)){
            return Retorno.error4("Error 4 -> No existe una conexión entre las sucursales "+ sucursal1.getCodigo() + " y " + sucursal2.getCodigo());
        }

        sucursalesGrafo.actualizarConexion(sucursal1,sucursal2,latencia);

        return Retorno.ok("Se actualizó la conexión entre las sucursales");
    }

    /*Descripción: Dado una sucursal cargar en el valorString el texto “SI” si es crítica y “NO” si no lo es.
    Retornos posibles: OK= Retorna en valorString la palabra SI/NO según corresponda
    ERROR1= Si el código es vacío o null.
    Error2= Si no existe la sucursal con ese código.
    NO_IMPLEMENTADA= Cuando aún no se implementó.*/

    @Override
    public Retorno analizarSucursal(String codigoSucursal) {
        if(codigoSucursal == null){
            return Retorno.error1("Error 1 -> el código es vacío o null");
        }
        if(codigoSucursal.isEmpty() ){
            return Retorno.error1("Error 1 -> el código es vacío o null");
        }
        Sucursal unaSucursal = new Sucursal((codigoSucursal));
        if(!sucursalesGrafo.existeVertice(unaSucursal)){
            return Retorno.error2("Error 2 -> No existe una sucursal con ese código");
        }
        if(sucursalesGrafo.esArticulacion(unaSucursal)){
            return Retorno.ok("SI");
        }else{
            return Retorno.ok("NO");
        }
    }

    /*Descripción: Retorna en valorString del retorno una lista de las sucursales ordenadas por código creciente que tengan una cantidad menor o igual a la latencia indicada como parámetro a la sucursal anfitriona.
    Retornos posibles: OK= Si el camino pudo ser calculado exitosamente.
    Retorna en valorEntero la latencia más grande de las sucursales seleccionadas.
    Retorna en valorString el listado de las sucursales ordenadas creciente por código.
    ERROR1= Si el código de la sucursal anfitriona es vacío o null.
    Error2= Si no existe el código de la sucursal anfitriona.
    Error3= Si la latencia es menor o igual a cero.
    NO_IMPLEMENTADA= Cuando aún no se implementó. */
    @Override
    public Retorno sucursalesParaTorneo(String codigoSucursalAnfitriona, int latenciaLimite) {
        if(codigoSucursalAnfitriona == null || codigoSucursalAnfitriona.isEmpty()){
            return Retorno.error1("Error 1 -> El codigo de la sucursal afitriona es vacio o null");
        }
        Sucursal sucAfitriona = new Sucursal(codigoSucursalAnfitriona);
        if(!sucursalesGrafo.existeVertice(sucAfitriona)){
            return Retorno.error2("Error 2 -> No existe el codigo de la sucursal afitriona");
        }
        if(latenciaLimite <= 0){
            return Retorno.error3("Error 3 -> La latencia es menor o igual a 0");
        }
        int[] valorEntero = {0};
        String sucursalesTorneo = sucursalesGrafo.sucursalesParaTorneo(sucAfitriona,latenciaLimite, valorEntero);
        return Retorno.ok(valorEntero[0], sucursalesTorneo);

    }

}
